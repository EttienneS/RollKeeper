export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "modules/rollkeeper/templates"
    ];
    return loadTemplates(templatePaths);
};
