import Tracker from "../Tracker.js";
export class ChatMessageParser {
    static getInstance() {
        if (!ChatMessageParser._instance)
            ChatMessageParser._instance = new ChatMessageParser();
        return ChatMessageParser._instance;
    }
    async parseMessage(chatMessage) {
        var _a, _b;
        const actorId = (_b = (_a = chatMessage === null || chatMessage === void 0 ? void 0 : chatMessage.data) === null || _a === void 0 ? void 0 : _a.speaker) === null || _b === void 0 ? void 0 : _b.actor;
        var roll = chatMessage.roll;
        if (actorId && roll) {
            var actor = game.actors.get(actorId);
            roll.dice.forEach((die) => {
                die.results.forEach((result) => {
                    Tracker.AddRoll(actor.name, result.result, die.faces);
                });
            });
            return;
        }
    }
}
export default ChatMessageParser.getInstance();
