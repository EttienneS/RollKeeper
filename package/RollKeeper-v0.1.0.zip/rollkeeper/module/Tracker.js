export class Tracker {
    static getInstance() {
        if (!Tracker._instance)
            Tracker._instance = new Tracker();
        return Tracker._instance;
    }
    get journal() {
        if (!this._journalEntry) {
            var name = "RollKeeper";
            this._journalEntry = game.journal.getName(name);
            if (!this._journalEntry) {
                const data = { name: name, type: "journal", content: "Current stats:<br/><br/>" };
                console.log(data);
                JournalEntry.create(data).then(function (entry) {
                    this._journalEntry = entry;
                    console.log('Created journal entry: ' + entry);
                });
            }
            else {
                console.log('Using existing journal entry: ' + this._journalEntry);
            }
        }
        return this._journalEntry;
    }
    async AddRoll(actorId, roll, die) {
        var journal = this.journal;
        var current = (journal.data);
        console.log(current);
        var update = { content: current.content + `${actorId} rolled ${roll} on a d${die}<br/>` };
        await journal.update(update);
        console.log(current);
    }
}
export default Tracker.getInstance();
